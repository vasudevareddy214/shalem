// import axios from "axios";
import { useState } from "react";

function Form() {
  let offshore = ["Chennai", "Bangalore", "Hyderabad", "Pune & Kochi"];
  let onshore = ["US", "Non US"];

  let [user, setUser] = useState({
    associateName: "",
    associateId: "",
    projectId: "",
    region: "",
    skillset: [],
    skills: [
      { name: "HTML5,CSS3,JS", checked: false },
      { name: "SASS", checked: false },
      { name: "ES5,ES6,ES7...", checked: false },
      { name: "Bootstrap 4", checked: false },
      { name: "Angular 8", checked: false },
      { name: "React JS", checked: false },
      { name: "Veu JS", checked: false },
      { name: "TypeScript", checked: false },
      { name: "Express JS", checked: false },
      { name: "Node JS", checked: false },
      { name: "Mango DB", checked: false },
    ],
    comment: "",
  });
  let [err, setErr] = useState("");
  let [selectedShore, setSelectedShore] = useState([]);
  const handleUserData = (event, index) => {
    let name = event.target.name;
    if (event.target.type === "checkbox") {
      let skillsArr = user.skills;
      let skillsetArr = [];
      skillsArr[index].checked = !skillsArr[index].checked;
      skillsArr.map((Obj) => {
        if (Obj.checked === true) {
          skillsetArr.push(Obj.name);
        }
        return 0;
      });
      setUser({ ...user, skills: skillsArr, skillset: skillsetArr });
    } else {
      let value = event.target.value;
      setUser({ ...user, [name]: value });
    }
  };
  const handleFormSubmit = async (event) => {
    event.preventDefault();
    let errors = validateUser(user);
    if (Object.keys(errors).length === 0) {
      // let res = await axios.post("http://localhost:4000/users", user);
      console.log(user);
      setErr("");
      // alert("new user created");
    } else {
      setErr(errors);
    }
  };
  const validateUser = (user) => {
    let errors = {};
    if (!user.associateName || user.associateName.match(/[^ ]/) == null) {
      errors.associateNameErr = "Please enter Associate Name";
    } else if (
      user.associateName.match(/^[A-Z a-z]*$/) == null ||
      user.associateName.length < 5 ||
      user.associateName.length > 30
    ) {
      errors.associateNameErr =
        "Accepts Alphabets, space & Min 5 to Max 30 Char";
    }
    if (!user.associateId) {
      errors.associateIdErr = "Please enter Associate Id";
    } else if (
      user.associateId.match(/^[0-9]+$/) == null ||
      user.associateId.length !== 6
    ) {
      errors.associateIdErr = "Invalid Associate Id";
    }
    if (!user.projectId) {
      errors.projectIdErr = "Please enter Project Id";
    } else if (
      user.projectId.length !== 12 ||
      user.projectId.match(/^[a-zA-Z0-9]+$/) == null
    ) {
      errors.projectIdErr = "Invalid Project Id";
    }
    if (!user.region) {
      errors.regionErr = "Please select Location";
    }
    if (!user.comment) {
      errors.commentErr = "Please enter comments";
    } else if (user.comment.match(/[^ ]/) == null) {
      errors.commentErr = "Please enter comments";
    }
    if (user.skillset.length < 5) {
      errors.skillsetErr = "Please select Min 5 skills";
      }
    if (!user.file) {
      errors.fileErr="please choose file";
    }
    return errors;
  };
  const selectShore = (e) => {
    if (e.target.value === "offshore") {
      setSelectedShore(offshore);
    }
    if (e.target.value === "onshore") {
      setSelectedShore(onshore);
    }
  };
  return (
    <div className="container">
      <form onSubmit={handleFormSubmit}>
        <h2>FORM VALIDATION</h2>
        <div className="mb-1w-75 mx-auto">
          <input
            className="form-control b-danger mt-4"
            type="text"
            placeholder="Associate Name"
            name="associateName"
            id="associateName"
            onChange={handleUserData}
          />
          {err.associateNameErr && (
            <p className="text-danger">{err.associateNameErr}</p>
          )}

          <input
            className="form-control mt-4"
            type="text"
            placeholder="Associate Id"
            name="associateId"
            id="associateId"
            onChange={handleUserData}
          />
          {err.associateIdErr && (
            <p className="text-danger">{err.associateIdErr}</p>
          )}

          <input
            className="form-control mt-4"
            type="text"
            placeholder="Project ID"
            name="projectId"
            id="projectId"
            onChange={handleUserData}
          />
          {err.projectIdErr && (
            <p className="text-danger">{err.projectIdErr}</p>
          )}
        </div>
        <div className="d-flex mt-3">
          <div className="form-check me-3">
            <input
              type="radio"
              name="site"
              id="offshore"
              value="offshore"
              className="form-check-input"
              onChange={selectShore}
            />
            <label className="form-check-label" htmlFor="offshore">
              Offshore
            </label>
          </div>
          <div className="form-check">
            <input
              type="radio"
              name="site"
              id="onshore"
              value="onshore"
              className="form-check-input"
              onChange={selectShore}
            />
            <label className="form-check-label" htmlFor="onshore">
              Onshore
            </label>
          </div>
        </div>
        <select
          className="form-select mt-4"
          name="region"
          onChange={handleUserData}
        >
          <option value="select location">select location</option>
          {selectedShore.map((region, index) => (
            <option value={region} key={index}>
              {region}
            </option>
          ))}
        </select>
        {err.regionErr && <p className="text-danger">{err.regionErr}</p>}
        <div className="mb-3 mt-4 row row-cols-1 row-cols-sm-2 row-cols-md-3 container">
          {user.skills.map((skill, index) => (
            <div className="form-check col" key={index}>
              <input
                type="checkbox"
                name={skill.name}
                id={skill.name}
                checked={skill.checked}
                className="form-check-input"
                onChange={(event) => handleUserData(event, index)}
              />
              <label htmlFor={skill.name} className="form-check-label">
                {skill.name}
              </label>
            </div>
          ))}
        </div>
        {err.skillsetErr && <p className="text-danger">{err.skillsetErr}</p>}
        <div>
          <label htmlFor="file" className="d-block">
            Upload Profile pic:
          </label>
          <input
            className="mt-2 "
            type="file"
            id="file"
            name="file"
            onChange={handleUserData}
          />
        </div>
        {err.fileErr && <p className="text-danger">{err.fileErr}</p>}          
          <textarea
          className="form-control mt-4"
          type="text"
          placeholder="Comments"
          name="comment"
          id="comment"
          rows={4}
          onChange={handleUserData}
        />
        {err.commentErr && <p className="text-danger">{err.commentErr}</p>}
        <button className="btn btn-primary mt-5" type="submit">
          Submit
        </button>
        <button className="btn btn-danger ms-1 mt-5" type="reset">
          Reset
        </button>
      </form>
    </div>
  );
}
export default Form;